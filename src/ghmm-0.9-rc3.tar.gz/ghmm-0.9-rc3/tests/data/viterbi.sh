#! /zpr/gnu/bin/bash

model=./test.smo
sequence=./test100.sqd
outfile=./viterbi.out

../shmm_viterbi_test $model $sequence $outfile